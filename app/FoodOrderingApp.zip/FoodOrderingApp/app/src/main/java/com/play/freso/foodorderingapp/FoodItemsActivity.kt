package com.play.freso.foodorderingapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.play.freso.foodorderingapp.adapters.FoodRecyclerAdapter
import com.play.freso.foodorderingapp.datasource.FoodDataSource
import com.play.freso.foodorderingapp.models.FoodItemPost
import javax.security.auth.DestroyFailedException


class FoodItemsActivity : AppCompatActivity(), FoodRecyclerAdapter.OnNoteListener{

    private val db = Firebase.firestore
    private lateinit var foodAdapter: FoodRecyclerAdapter
    private lateinit var recycler_view: RecyclerView
    private lateinit var category: String
    private var foodItems = ArrayList<FoodItemPost>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("help", "Created")
        setContentView(R.layout.activity_food_items)
        category = intent.getStringExtra("category") ?: "whoops :,)"

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "$category Items"

        initRecyclerView()


//        val cat: String?,
//        val name: String?,
//        val price: Double,
//        val desc: String?,
//        val img: String?

        db.collection("food_items")
            .whereEqualTo("cat", category)
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    Log.d("food_items", "${document.id} => ${document.data}")
                    foodItems.add(
                            FoodItemPost(
                            document.data["cat"].toString(),
                            document.data["name"].toString(),
                            document.data["price"].toString(),
                            document.data["desc"].toString(),
                            document.data["img"].toString()
                        )
                    )
                }
                initRecyclerView()
            }
            .addOnFailureListener { exception ->
                Log.w("food_items", "Error getting documents.", exception)
            }
    }
    


    private fun initRecyclerView(){
        recycler_view = findViewById<RecyclerView>(R.id.recycler_view)
        recycler_view.apply{
            layoutManager = LinearLayoutManager(this@FoodItemsActivity)
            val topSpacingDecoration = TopSpacingItemDecoration(30)
            addItemDecoration(topSpacingDecoration)
            foodAdapter = FoodRecyclerAdapter(this@FoodItemsActivity)
            adapter = foodAdapter
            foodAdapter.submitList(foodItems)
        }
    }

    override fun onNoteClick(position: Int) {
        val bundle = Bundle()
        val food_item = foodItems[position]
        val intent = Intent(this, FoodDetailsActivity::class.java).apply{
            bundle.putParcelable("selected_item", food_item)
            putExtra("bundle", bundle)
        }
        startActivity(intent)
    }


}