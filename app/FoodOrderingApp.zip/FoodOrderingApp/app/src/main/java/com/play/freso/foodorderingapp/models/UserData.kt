package com.play.freso.foodorderingapp.models

data class UserData ( val username: String,
                      val password: String){
}