package com.play.freso.foodorderingapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.play.freso.foodorderingapp.models.FoodItemPost
import kotlinx.android.synthetic.main.activity_food_details.*
import kotlinx.android.synthetic.main.activity_food_details.food_price


class FoodDetailsActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food_details)


        val bundle = intent.getBundleExtra("bundle")
        val foodItem = bundle?.getParcelable<FoodItemPost>("selected_item")

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Item Details"

        bind(foodItem?.name, foodItem?.img, foodItem?.desc, foodItem?.price)
    }

    private fun bind(foodName: String?, foodImg: String?, foodDesc: String?, foodPrice: String?){

        food_title.text = foodName
        food_desc.text = foodDesc
        food_price.text = foodPrice

        val requestOptions = RequestOptions()
            .placeholder(R.drawable.ic_launcher_background)
            .error(R.drawable.ic_launcher_background)

        Glide.with(this)
            .applyDefaultRequestOptions(requestOptions)
            .load(foodImg)
            .into(food_image)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }

}